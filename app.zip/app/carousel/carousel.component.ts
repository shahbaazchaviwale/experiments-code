import { Component, OnInit, ViewChild } from '@angular/core';
import { OwlCarousel } from 'ngx-owl-carousel';

@Component({
  selector: "app-carousel",
  templateUrl: "./carousel.component.html",
  styleUrls: ["./carousel.component.scss"]
})
export class CarouselComponent implements OnInit {
  myCarouselImages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16].map(
    i => `https://picsum.photos/640/480?image=${i}`
  );
  mySlideOptions = { items: 1, dots: true, nav: false };
  myCarouselOptions = { items: 10, dots: true, nav: false };

  @ViewChild("owlElement") owlElement: OwlCarousel;
  
  constructor() {}

  ngOnInit() {}

  ChangeImage(direction) {
    if (direction === 'next'){
      this.owlElement.next([200]);
    }else{
      this.owlElement.previous([200]);
    }
    
    //duration 200ms
  }
}
